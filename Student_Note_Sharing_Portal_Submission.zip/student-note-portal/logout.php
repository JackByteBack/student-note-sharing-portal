<?php
/** Logout (session destroyed server-side). */
declare(strict_types=1);
require_once __DIR__ . '/includes/auth.php';

logout_user();
redirect('login.php');
